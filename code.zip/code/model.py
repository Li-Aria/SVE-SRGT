from layers import *

class MultiDeep(nn.Module):
    def __init__(self, nlncfeat, nmifeat, ndrugfeat, dim_hidden):

        super(MultiDeep, self).__init__()
        # SVE-SRGT model
        self.trans_mid = SVE_SRGT(nlncfeat, nmifeat, ndrugfeat,dim_hidden,
                                                nheads=4,
                                                dropout=0.3,
                                                num_layers=2,
                                                twohop_init_lambda_disease=0.15,
                                                twohop_init_lambda_mrna=0.1,
                                                learnable_twohop_lambda=False,
                                                edge_magnitude_mode="post_softmax",
                                                debug_twohop=False
                                            )

        self.FClayer1 = nn.Linear(dim_hidden, dim_hidden)
        self.FClayer2 = nn.Linear(dim_hidden, 32)
        self.FClayer3 = nn.Linear(32, 1)

        self.output = nn.Sigmoid()

    def forward(self, lnc_features, mi_features, d_feature, idx_nc_drug, device, lmi_adj, lda_adj, mda_adj,
                ldis_adj, mdis_adj, ddis_adj, lm_adj, mm_adj, dm_adj):

        lnc_bgcn, mi_bgcn, drug_bgcn = self.trans_mid(lnc_features, mi_features, d_feature,
                                                      lmi_adj, lda_adj, mda_adj, ldis_adj, mdis_adj, ddis_adj, lm_adj, mm_adj, dm_adj,
                                                      mid_node_mode="both",
                                                      twohop_topk_disease=40,
                                                      twohop_topk_mrna=20,
                                                      twohop_lambda_disease=0.15,
                                                      twohop_lambda_mrna=0.1,
                                                      twohop_mode="RA",
                                                      )

        lnc_x = self.lnc_prolayer1(lnc_bgcn)
        drug_x = self.lnc_prolayer1(drug_bgcn)
        mi_x = self.mi_prolayer1(mi_bgcn)

        # use Hadamard to splice
        paira_features = lnc_x[idx_nc_drug[:, 0]]
        pairb_features = drug_x[idx_nc_drug[:, 1]]
        pairs_x = paira_features * pairb_features

        pairs_x = pairs_x.to(device)
        pairs_x = self.FClayer1(pairs_x)
        pairs_x = F.relu(pairs_x)
        pairs_x = self.FClayer2(pairs_x)
        pairs_x = F.relu(pairs_x)
        pairs_x = self.FClayer3(pairs_x)
        pairs_x = pairs_x.squeeze(-1)
        return pairs_x
