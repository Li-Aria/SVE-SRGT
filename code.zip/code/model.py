from layers import *
import torch
import torch.nn as nn
import torch.nn.functional as F

class MultiDeep(nn.Module):
    def __init__(self, nlncfeat, nmifeat, ndrugfeat, dim_hidden, task="mda"):

        super(MultiDeep, self).__init__()
        if task not in {"mda", "lda"}:
            raise ValueError("task must be either 'mda' or 'lda'")
        self.task = task
        # SVE-SRGT model
        self.trans_mid = SVE_SRGT(nlncfeat, nmifeat, ndrugfeat,dim_hidden,
                                                nheads=4,
                                                dropout=0.3,
                                                num_layers=2,
                                                twohop_init_lambda_disease=0.15,
                                                twohop_init_lambda_mrna=0.1,
                                                learnable_twohop_lambda=False,
                                                edge_magnitude_mode="post_softmax"
                                            )

        self.FClayer1 = nn.Linear(dim_hidden, dim_hidden)
        self.FClayer2 = nn.Linear(dim_hidden, 32)
        self.FClayer3 = nn.Linear(32, 1)

        # Project each node type separately; drug and lncRNA must not share a projection layer.
        self.lnc_prolayer1 = nn.Linear(dim_hidden, dim_hidden)
        self.mi_prolayer1 = nn.Linear(dim_hidden, dim_hidden)
        self.drug_prolayer1 = nn.Linear(dim_hidden, dim_hidden)

    def forward(self, lnc_features, mi_features, d_feature, idx_nc_drug, device, lmi_adj, lda_adj, mda_adj,
                ldis_adj, mdis_adj, ddis_adj, lm_adj, mm_adj, dm_adj):

        lnc_bgcn, mi_bgcn, drug_bgcn = self.trans_mid(lnc_features, mi_features, d_feature,
                                                      lmi_adj, lda_adj, mda_adj, ldis_adj, mdis_adj, ddis_adj, lm_adj, mm_adj, dm_adj,
                                                      mid_node_mode="both",
                                                      twohop_topk_disease=40,
                                                      twohop_topk_mrna=20,
                                                      twohop_lambda_disease=0.15,
                                                      twohop_lambda_mrna=0.1,
                                                      twohop_mode_disease="RA",
                                                      twohop_mode_mrna="RA",
                                                      )

        lnc_x = self.lnc_prolayer1(lnc_bgcn)
        mi_x = self.mi_prolayer1(mi_bgcn)
        drug_x = self.drug_prolayer1(drug_bgcn)

        # Select the appropriate ncRNA representation for the current task.
        idx_nc_drug = torch.as_tensor(
            idx_nc_drug, dtype=torch.long, device=drug_x.device
        )
        nc_x = mi_x if self.task == "mda" else lnc_x
        paira_features = nc_x[idx_nc_drug[:, 0]]
        pairb_features = drug_x[idx_nc_drug[:, 1]]
        pairs_x = paira_features * pairb_features

        pairs_x = pairs_x.to(device)
        pairs_x = self.FClayer1(pairs_x)
        pairs_x = F.relu(pairs_x)
        pairs_x = self.FClayer2(pairs_x)
        pairs_x = F.relu(pairs_x)
        pairs_x = self.FClayer3(pairs_x)
        pairs_x = pairs_x.squeeze(-1)
        return pairs_x
