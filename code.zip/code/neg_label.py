import argparse
import math
import random
from collections import deque
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple
import pandas as pd


Pair = Tuple[int, int]
Sample = Tuple[int, int, int]


def read_first_field_lines(path: str, encoding: str = "utf-8") -> List[str]:
    names: List[str] = []
    seen: Set[str] = set()

    with open(path, "r", encoding=encoding, errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            token = line.split(",")[0]
            token = token.split("\t")[0]
            token = token.split(" ")[0]
            token = token.strip()

            if token and token not in seen:
                names.append(token)
                seen.add(token)

    return names


def read_names_from_csv(path: str, name_col: Optional[str] = None) -> List[str]:
    if name_col is None or str(name_col).lower() == "none":
        return read_first_field_lines(path)

    df = pd.read_csv(path)
    if name_col not in df.columns:
        raise ValueError(f"Column '{name_col}' not found in file '{path}'. "f"Available columns: {list(df.columns)}")

    names: List[str] = []
    seen: Set[str] = set()
    for value in df[name_col].astype(str).tolist():
        value = value.strip()
        if value and value.lower() != "nan" and value not in seen:
            names.append(value)
            seen.add(value)

    return names


def bfs_dist_from(start: int, adj: Sequence[Sequence[int]]) -> Dict[int, int]:
    dist = {start: 0}
    q = deque([start])

    while q:
        x = q.popleft()
        dx = dist[x]
        for y in adj[x]:
            if y not in dist:
                dist[y] = dx + 1
                q.append(y)

    return dist


def read_positive_pairs(
    pairs_path: str,
    left_col: str,
    right_col: str,
    left2idx: Dict[str, int],
    right2idx: Dict[str, int],
) -> Set[Pair]:
    df = pd.read_csv(pairs_path)

    if left_col not in df.columns or right_col not in df.columns:
        raise ValueError(
            f"Missing required columns '{left_col}' and/or '{right_col}' in '{pairs_path}'. "
            f"Available columns: {list(df.columns)}"
        )

    pos_edges: Set[Pair] = set()
    filtered_left = 0
    filtered_right = 0

    for _, row in df.iterrows():
        left_name = str(row[left_col]).strip()
        right_name = str(row[right_col]).strip()

        if left_name not in left2idx:
            filtered_left += 1
            continue
        if right_name not in right2idx:
            filtered_right += 1
            continue

        pos_edges.add((left2idx[left_name], right2idx[right_name]))

    return pos_edges


def build_bipartite_graph(L: int, D: int, pos_edges: Iterable[Pair]) -> List[List[int]]:

    adj: List[List[int]] = [[] for _ in range(L + D)]

    for li, di in pos_edges:
        u = li
        v = L + di
        adj[u].append(v)
        adj[v].append(u)

    return adj


def build_distance_filtered_negative_candidates(
    L: int,
    D: int,
    all_pos_edges: Set[Pair],
    full_adj: Sequence[Sequence[int]],
    dist_threshold: int = 3,
) -> List[Pair]:

    dist_cache = [bfs_dist_from(li, full_adj) for li in range(L)]
    candidates: List[Pair] = []

    for li in range(L):
        dist_from_li = dist_cache[li]
        for di in range(D):
            pair = (li, di)
            if pair in all_pos_edges:
                continue

            right_node = L + di
            distance = dist_from_li.get(right_node, math.inf)
            if distance > dist_threshold:
                candidates.append(pair)

    return candidates


def sample_equal_negatives(
    candidates: Sequence[Pair],
    num_needed: int,
    seed: int = 42,
) -> List[Pair]:

    if len(candidates) < num_needed:
        raise RuntimeError(
            f"Insufficient negative candidates satisfying the distance constraint "
            f"to maintain a 1:1 positive-to-negative ratio. "
            f"Found {len(candidates)} candidates, but {num_needed} are required. "
            f"Consider reducing '--dist_threshold' or verifying the complete node set."
        )

    rng = random.Random(seed)
    candidates = list(candidates)
    rng.shuffle(candidates)
    return candidates[:num_needed]


def stratified_split_samples(
    pos_edges: Sequence[Pair],
    neg_edges: Sequence[Pair],
    test_size: float = 0.1,
    seed: int = 2026,
) -> Tuple[List[Sample], List[Sample]]:


    rng = random.Random(seed)
    pos_edges = list(pos_edges)
    neg_edges = list(neg_edges)
    rng.shuffle(pos_edges)
    rng.shuffle(neg_edges)

    n_test_pos = max(1, int(round(len(pos_edges) * test_size)))
    n_test_neg = n_test_pos

    test_pos = pos_edges[:n_test_pos]
    train_pos = pos_edges[n_test_pos:]

    test_neg = neg_edges[:n_test_neg]
    train_neg = neg_edges[n_test_neg:]

    train_samples: List[Sample] = [(li, di, 1) for li, di in train_pos] + [(li, di, 0) for li, di in train_neg]
    test_samples: List[Sample] = [(li, di, 1) for li, di in test_pos] + [(li, di, 0) for li, di in test_neg]

    rng.shuffle(train_samples)
    rng.shuffle(test_samples)

    return train_samples, test_samples


def save_samples(samples: Sequence[Sample], output_path: str) -> None:
    with open(output_path, "w", encoding="utf-8") as f:
        for li, di, label in samples:
            f.write(f"{li}\t{di}\t{label}\n")

    pos_num = sum(1 for _, _, y in samples if y == 1)
    neg_num = sum(1 for _, _, y in samples if y == 0)
    print(f"Saved to {output_path}；Total samples:{len(samples)}，Positive:{pos_num}，Negative:{neg_num}")


def build_dataset(
    pairs_path: str,
    left_name_path: str,
    right_name_path: str,
    output_prefix: str,
    left_col: str,
    right_col: str,
    left_name_col: Optional[str] = None,
    right_name_col: Optional[str] = None,
    test_size: float = 0.1,
    dist_threshold: int = 3,
    seed: int = 2026,
) -> None:

    left_names = read_names_from_csv(left_name_path, left_name_col)
    right_names = read_names_from_csv(right_name_path, right_name_col)

    left2idx = {name: i for i, name in enumerate(left_names)}
    right2idx = {name: i for i, name in enumerate(right_names)}

    L, D = len(left_names), len(right_names)

    all_pos_edges = read_positive_pairs(
        pairs_path=pairs_path,
        left_col=left_col,
        right_col=right_col,
        left2idx=left2idx,
        right2idx=right2idx,
    )

    full_adj = build_bipartite_graph(L, D, all_pos_edges)

    neg_candidates = build_distance_filtered_negative_candidates(
        L=L,
        D=D,
        all_pos_edges=all_pos_edges,
        full_adj=full_adj,
        dist_threshold=dist_threshold,
    )

    neg_edges = sample_equal_negatives(
        candidates=neg_candidates,
        num_needed=len(all_pos_edges),
        seed=seed,
    )

    train_samples, test_samples = stratified_split_samples(
        pos_edges=sorted(all_pos_edges),
        neg_edges=neg_edges,
        test_size=test_size,
        seed=seed,
    )

    save_samples(train_samples, f"{output_prefix}_train.txt")
    save_samples(test_samples, f"{output_prefix}_test.txt")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()

    parser.add_argument("--pairs_path", type=str, default="Pairs file path")
    parser.add_argument("--left_name_path", type=str, default="Left node name file path")
    parser.add_argument("--right_name_path", type=str, default="Right node name file path")
    parser.add_argument("--output_prefix", type=str, default="Output file prefix")

    parser.add_argument("--left_col", type=str, default="lncRNA")
    parser.add_argument("--right_col", type=str, default="DBID")

    parser.add_argument("--left_name_col", type=str, default=None, help="Left node name file column name")
    parser.add_argument("--right_name_col", type=str, default=None, help="Right node name file column name")

    parser.add_argument("--test_size", type=float, default=0.1)
    parser.add_argument("--dist_threshold", type=int, default=2, help="Distance is greater than the threshold.")
    parser.add_argument("--seed", type=int, default=2026, help="random seed")

    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    build_dataset(
        pairs_path=args.pairs_path,
        left_name_path=args.left_name_path,
        right_name_path=args.right_name_path,
        output_prefix=args.output_prefix,
        left_col=args.left_col,
        right_col=args.right_col,
        left_name_col=args.left_name_col,
        right_name_col=args.right_name_col,
        test_size=args.test_size,
        dist_threshold=args.dist_threshold,
        seed=args.seed,
    )
