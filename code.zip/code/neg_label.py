
import argparse
import math
import random
from collections import deque
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple

import pandas as pd


Pair = Tuple[int, int]
Sample = Tuple[int, int, int]


def read_first_field_lines(path: str, encoding: str = "utf-8") -> List[str]:
    names: List[str] = []
    seen: Set[str] = set()

    with open(path, "r", encoding=encoding, errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            # Support comma-, tab-, and space-delimited input.
            token = line.split(",")[0]
            token = token.split("\t")[0]
            token = token.split(" ")[0]
            token = token.strip()

            if token and token not in seen:
                names.append(token)
                seen.add(token)

    return names


def read_names_from_csv(path: str, name_col: Optional[str] = None) -> List[str]:

    if name_col is None or str(name_col).lower() == "none":
        return read_first_field_lines(path)

    df = pd.read_csv(path)
    if name_col not in df.columns:
        raise ValueError(
            f"Column {name_col!r} was not found in {path}; "
            f"available columns: {list(df.columns)}"
        )

    names: List[str] = []
    seen: Set[str] = set()
    for value in df[name_col].astype(str).tolist():
        value = value.strip()
        if value and value.lower() != "nan" and value not in seen:
            names.append(value)
            seen.add(value)

    return names

# Run BFS from start and return shortest-path lengths to reachable nodes
def bfs_dist_from(start: int, adj: Sequence[Sequence[int]]) -> Dict[int, int]:
    dist = {start: 0}
    q = deque([start])

    while q:
        x = q.popleft()
        dx = dist[x]
        for y in adj[x]:
            if y not in dist:
                dist[y] = dx + 1
                q.append(y)

    return dist


def read_positive_pairs(
    pairs_path: str,
    left_col: str,
    right_col: str,
    left2idx: Dict[str, int],
    right2idx: Dict[str, int],
) -> Set[Pair]:
    df = pd.read_csv(pairs_path)

    if left_col not in df.columns or right_col not in df.columns:
        raise ValueError(
            f"Required columns {left_col!r} and {right_col!r} were not found "
            f"in {pairs_path}; available columns: {list(df.columns)}"
        )

    pos_edges: Set[Pair] = set()
    filtered_left = 0
    filtered_right = 0

    for _, row in df.iterrows():
        left_name = str(row[left_col]).strip()
        right_name = str(row[right_col]).strip()

        if left_name not in left2idx:
            filtered_left += 1
            continue
        if right_name not in right2idx:
            filtered_right += 1
            continue

        pos_edges.add((left2idx[left_name], right2idx[right_name]))

    if not pos_edges:
        raise RuntimeError(
            "No positive pairs remain after filtering. Verify the association "
            "columns and node-name files."
        )

    print(f"Valid positive pairs after deduplication: {len(pos_edges)}")
    if filtered_left or filtered_right:
        print(
            f"Filtered rows: unknown left nodes={filtered_left}, "
            f"unknown right nodes={filtered_right}"
        )

    return pos_edges


def build_bipartite_graph(L: int, D: int, pos_edges: Iterable[Pair]) -> List[List[int]]:
    adj: List[List[int]] = [[] for _ in range(L + D)]

    for li, di in pos_edges:
        u = li
        v = L + di
        adj[u].append(v)
        adj[v].append(u)

    return adj


def build_distance_filtered_negative_candidates(
    L: int,
    D: int,
    all_pos_edges: Set[Pair],
    full_adj: Sequence[Sequence[int]],
    dist_threshold: int = 3,
) -> List[Pair]:

    # shortest-path distance must exceed dist_threshold
    dist_cache = [bfs_dist_from(li, full_adj) for li in range(L)]
    candidates: List[Pair] = []

    for li in range(L):
        dist_from_li = dist_cache[li]
        for di in range(D):
            pair = (li, di)
            if pair in all_pos_edges:
                continue

            right_node = L + di
            distance = dist_from_li.get(right_node, math.inf)
            if distance > dist_threshold:
                candidates.append(pair)

    return candidates


def sample_equal_negatives(
    candidates: Sequence[Pair],
    num_needed: int,
    seed: int = 42,
) -> List[Pair]:
    """Randomly select the requested number of negative pairs."""
    if len(candidates) < num_needed:
        raise RuntimeError(
            "Insufficient distance-qualified negative candidates for a 1:1 ratio. "
            f"Available={len(candidates)}, required={num_needed}. "
            "Consider lowering --dist_threshold or checking the node lists."
        )

    rng = random.Random(seed)
    candidates = list(candidates)
    rng.shuffle(candidates)
    return candidates[:num_needed]


# Split positive pairs before graph construction
def split_positive_edges(
    pos_edges: Sequence[Pair],
    test_size: float = 0.1,
    seed: int = 2026,
) -> Tuple[List[Pair], List[Pair]]:

    if not 0 < test_size < 1:
        raise ValueError("test_size must be in the open interval (0, 1).")

    rng = random.Random(seed)
    pos_edges = list(pos_edges)
    rng.shuffle(pos_edges)

    n_test_pos = max(1, int(round(len(pos_edges) * test_size)))
    test_pos = pos_edges[:n_test_pos]
    train_pos = pos_edges[n_test_pos:]
    if not train_pos:
        raise RuntimeError("The training-positive set is empty; reduce --test_size.")

    return train_pos, test_pos


# Randomly sample independent-test negatives from all unknown pairs
def sample_random_unknown_negatives(
    L: int,
    D: int,
    all_pos_edges: Set[Pair],
    num_needed: int,
    seed: int,
) -> List[Pair]:

    unknown_num = L * D - len(all_pos_edges)
    if unknown_num < num_needed:
        raise RuntimeError(
            f"Insufficient unknown pairs: available={unknown_num}, required={num_needed}."
        )

    unknown_pairs = [
        (li, di)
        for li in range(L)
        for di in range(D)
        if (li, di) not in all_pos_edges
    ]
    rng = random.Random(seed)
    return rng.sample(unknown_pairs, num_needed)


def assemble_samples(
    train_pos: Sequence[Pair],
    train_neg: Sequence[Pair],
    test_pos: Sequence[Pair],
    test_neg: Sequence[Pair],
    seed: int,
) -> Tuple[List[Sample], List[Sample]]:
    """Assemble and shuffle the training and independent test sets."""
    if len(train_pos) != len(train_neg):
        raise RuntimeError(
            f"Training set is not balanced: positives={len(train_pos)}, "
            f"negatives={len(train_neg)}"
        )
    if len(test_pos) != len(test_neg):
        raise RuntimeError(
            f"Test set is not balanced: positives={len(test_pos)}, "
            f"negatives={len(test_neg)}"
        )

    train_samples: List[Sample] = [(li, di, 1) for li, di in train_pos] + [(li, di, 0) for li, di in train_neg]
    test_samples: List[Sample] = [(li, di, 1) for li, di in test_pos] + [(li, di, 0) for li, di in test_neg]

    rng = random.Random(seed)
    rng.shuffle(train_samples)
    rng.shuffle(test_samples)

    return train_samples, test_samples


def validate_samples(train_samples: Sequence[Sample], test_samples: Sequence[Sample]) -> None:
    """Validate uniqueness, label consistency, set separation, and class balance."""
    if len(set(train_samples)) != len(train_samples):
        raise RuntimeError("The training set contains duplicate sample triples.")
    if len(set(test_samples)) != len(test_samples):
        raise RuntimeError("The test set contains duplicate sample triples.")

    train_pairs = [(li, di) for li, di, _ in train_samples]
    test_pairs = [(li, di) for li, di, _ in test_samples]

    if len(set(train_pairs)) != len(train_pairs):
        raise RuntimeError("The training set contains duplicate pairs or label conflicts.")
    if len(set(test_pairs)) != len(test_pairs):
        raise RuntimeError("The test set contains duplicate pairs or label conflicts.")

    overlap_pairs = set(train_pairs) & set(test_pairs)
    if overlap_pairs:
        raise RuntimeError(
            f"Training and test sets overlap by {len(overlap_pairs)} pairs."
        )

    train_pos = sum(1 for _, _, y in train_samples if y == 1)
    train_neg = sum(1 for _, _, y in train_samples if y == 0)
    test_pos = sum(1 for _, _, y in test_samples if y == 1)
    test_neg = sum(1 for _, _, y in test_samples if y == 0)

    if train_pos != train_neg:
        raise RuntimeError(
            f"Training set is not 1:1: positives={train_pos}, negatives={train_neg}"
        )
    if test_pos != test_neg:
        raise RuntimeError(
            f"Test set is not 1:1: positives={test_pos}, negatives={test_neg}"
        )


def save_samples(samples: Sequence[Sample], output_path: str) -> None:
    """Save samples as left_idx, right_idx, and label separated by tabs."""
    with open(output_path, "w", encoding="utf-8") as f:
        for li, di, label in samples:
            f.write(f"{li}\t{di}\t{label}\n")

    pos_num = sum(1 for _, _, y in samples if y == 1)
    neg_num = sum(1 for _, _, y in samples if y == 0)
    print(
        f"Saved {output_path}: total={len(samples)}, "
        f"positives={pos_num}, negatives={neg_num}"
    )

# Read a three-column indexed sample file and validate binary labels
def read_index_samples(path: str) -> List[Sample]:
    samples: List[Sample] = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line_number, line in enumerate(f, start=1):
            parts = line.strip().split()
            if not parts:
                continue
            if len(parts) != 3:
                raise ValueError(
                    f"{path}, line {line_number}: expected three columns; got {line.strip()!r}"
                )
            li, di, label = map(int, parts)
            if label not in {0, 1}:
                raise ValueError(
                    f"{path}, line {line_number}: label must be 0 or 1; got {label}"
                )
            samples.append((li, di, label))
    return samples


# Keep the existing training set and test positives, then resample test negatives
def rebuild_random_test_from_existing(
    train_path: str,
    test_path: str,
    output_path: str,
    num_left: int,
    num_right: int,
    seed: int,
) -> None:

    train_samples = read_index_samples(train_path)
    old_test_samples = read_index_samples(test_path)

    for source, samples in (("training set", train_samples), ("test set", old_test_samples)):
        for li, di, _ in samples:
            if not (0 <= li < num_left and 0 <= di < num_right):
                raise IndexError(
                    f"Out-of-range index in {source}: ({li}, {di}); "
                    f"valid ranges are left=[0,{num_left - 1}] and "
                    f"right=[0,{num_right - 1}]"
                )

    train_pairs = {(li, di) for li, di, _ in train_samples}
    if len(train_pairs) != len(train_samples):
        raise RuntimeError("The existing training set contains duplicate pairs.")

    test_pos = sorted({(li, di) for li, di, label in old_test_samples if label == 1})
    if not test_pos:
        raise RuntimeError("The existing test set contains no positive samples.")

    train_pos = {(li, di) for li, di, label in train_samples if label == 1}
    all_known_pos = train_pos | set(test_pos)
    overlap = train_pairs & set(test_pos)
    if overlap:
        raise RuntimeError(
            f"The training set overlaps with {len(overlap)} positive test pairs."
        )

    # Skip graph distances and directly exclude known positives and all training pairs.
    random_test_candidates = [
        (li, di)
        for li in range(num_left)
        for di in range(num_right)
        if (li, di) not in all_known_pos and (li, di) not in train_pairs
    ]
    if len(random_test_candidates) < len(test_pos):
        raise RuntimeError(
            "Insufficient random test-negative candidates: "
            f"available={len(random_test_candidates)}, required={len(test_pos)}."
        )

    rng = random.Random(seed)
    test_neg = rng.sample(random_test_candidates, len(test_pos))
    new_test_samples: List[Sample] = [
        (li, di, 1) for li, di in test_pos
    ] + [
        (li, di, 0) for li, di in test_neg
    ]
    rng.shuffle(new_test_samples)

    validate_samples(train_samples, new_test_samples)
    save_samples(new_test_samples, output_path)


def build_dataset(
    pairs_path: str,
    left_name_path: str,
    right_name_path: str,
    output_prefix: str,
    left_col: str,
    right_col: str,
    left_name_col: Optional[str] = None,
    right_name_col: Optional[str] = None,
    test_size: float = 0.1,
    dist_threshold: int = 2,
    seed: int = 2026,
) -> None:
    """Build a distance-constrained training set and a random independent test set."""
    left_names = read_names_from_csv(left_name_path, left_name_col)
    right_names = read_names_from_csv(right_name_path, right_name_col)

    left2idx = {name: i for i, name in enumerate(left_names)}
    right2idx = {name: i for i, name in enumerate(right_names)}

    L, D = len(left_names), len(right_names)
    print(f"Left nodes={L}, right nodes={D}")

    all_pos_edges = read_positive_pairs(
        pairs_path=pairs_path,
        left_col=left_col,
        right_col=right_col,
        left2idx=left2idx,
        right2idx=right2idx,
    )

    train_pos, test_pos = split_positive_edges(
        pos_edges=sorted(all_pos_edges),
        test_size=test_size,
        seed=seed,
    )
    print(f"Training positives={len(train_pos)}, test positives={len(test_pos)}")

    test_neg = sample_random_unknown_negatives(
        L=L,
        D=D,
        all_pos_edges=all_pos_edges,
        num_needed=len(test_pos),
        seed=seed + 1,
    )

    train_adj = build_bipartite_graph(L, D, train_pos)

    print(f"Building training-negative candidates with distance > {dist_threshold}...")
    train_neg_candidates = build_distance_filtered_negative_candidates(
        L=L,
        D=D,
        all_pos_edges=all_pos_edges,
        full_adj=train_adj,
        dist_threshold=dist_threshold,
    )
    # Test negatives must not be reused in the training set.
    test_neg_set = set(test_neg)
    train_neg_candidates = [
        pair for pair in train_neg_candidates if pair not in test_neg_set
    ]
    print(f"Eligible training-negative candidates={len(train_neg_candidates)}")

    train_neg = sample_equal_negatives(
        candidates=train_neg_candidates,
        num_needed=len(train_pos),
        seed=seed + 2,
    )

    train_samples, test_samples = assemble_samples(
        train_pos=train_pos,
        train_neg=train_neg,
        test_pos=test_pos,
        test_neg=test_neg,
        seed=seed,
    )

    validate_samples(train_samples, test_samples)

    save_samples(train_samples, f"{output_prefix}_train_gra4.txt")
    save_samples(test_samples, f"{output_prefix}_test_gra4.txt")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Build distance-constrained training negatives and random test "
            "negatives without distance filtering."
        )
    )

    parser.add_argument("--pairs_path", type=str, default="fnial_output/LDA_pairs.csv", help="Path to the positive-association file.")
    parser.add_argument("--left_name_path", type=str, default="lncRNA_name.csv", help="Path to the left-node name file.")
    parser.add_argument("--right_name_path", type=str, default="drug_smiles.csv", help="Path to the right-node name file.")
    parser.add_argument("--output_prefix", type=str, default="LDA", help="Output filename prefix.")

    parser.add_argument("--left_col", type=str, default="lncRNA", help="Left-node column in the association file.")
    parser.add_argument("--right_col", type=str, default="DBID", help="Right-node column in the association file.")

    parser.add_argument("--left_name_col", type=str, default=None, help="Column in the left-node name file; use None for a headerless file.")
    parser.add_argument("--right_name_col", type=str, default="DBID", help="Column in the right-node name file; use None for a headerless file.")

    parser.add_argument("--test_size", type=float, default=0.1, help="Fraction of positive pairs assigned to the independent test set.")
    parser.add_argument("--dist_threshold", type=int, default=3, help="Minimum exclusive shortest-path threshold for training negatives.")
    parser.add_argument("--seed", type=int, default=42, help="Random seed.")

    parser.add_argument("--existing_train_path", type=str, default=None, help="Existing three-column training file; provide it with existing_test_path to rebuild the test set.")
    parser.add_argument("--existing_test_path", type=str, default=None, help="Existing three-column test file; only its positive samples are retained.")
    parser.add_argument("--random_test_output", type=str, default="LDA_test_random.txt", help="Output path for the rebuilt random-negative test set.")
    parser.add_argument("--num_left", type=int, default=641, help="Total number of left nodes.")
    parser.add_argument("--num_right", type=int, default=171, help="Total number of right nodes.")

    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    if args.existing_train_path or args.existing_test_path:
        if not args.existing_train_path or not args.existing_test_path:
            raise ValueError(
                "--existing_train_path and --existing_test_path must be provided together."
            )
        rebuild_random_test_from_existing(
            train_path=args.existing_train_path,
            test_path=args.existing_test_path,
            output_path=args.random_test_output,
            num_left=args.num_left,
            num_right=args.num_right,
            seed=args.seed,
        )
    else:
        build_dataset(
            pairs_path=args.pairs_path,
            left_name_path=args.left_name_path,
            right_name_path=args.right_name_path,
            output_prefix=args.output_prefix,
            left_col=args.left_col,
            right_col=args.right_col,
            left_name_col=args.left_name_col,
            right_name_col=args.right_name_col,
            test_size=args.test_size,
            dist_threshold=args.dist_threshold,
            seed=args.seed,
        )
