import math
from typing import Dict, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


def _row_normalize_scores(
    scores: Optional[torch.Tensor],
    eps: float = 1e-9,
) -> Optional[torch.Tensor]:

    if scores is None:
        return None

    row_max = scores.max(dim=1, keepdim=True).values
    return torch.where(row_max > 0, scores / (row_max + eps), torch.zeros_like(scores))


def _filter_high_degree_mid_nodes(
    A_src_mid: torch.Tensor,
    A_mid_dst: torch.Tensor,
    mid_degree: torch.Tensor,
    max_mid_degree: Optional[float] = None,
    drop_top_mid_ratio: float = 0.0,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:

    keep = torch.ones_like(mid_degree, dtype=torch.bool)

    if max_mid_degree is not None:
        keep &= (mid_degree <= float(max_mid_degree))

    if drop_top_mid_ratio > 0:
        n_mid = mid_degree.numel()
        n_drop = int(math.floor(n_mid * drop_top_mid_ratio))

        if 0 < n_drop < n_mid:
            _, idx = torch.topk(mid_degree, k=n_drop)
            keep_ratio = torch.ones_like(keep)
            keep_ratio[idx] = False
            keep &= keep_ratio

    return (A_src_mid[:, keep], A_mid_dst[keep, :], mid_degree[keep])

# Retain only the Top-K highest-scoring virtual neighbors
def _apply_topk_by_row(
    scores: torch.Tensor,
    topk: Optional[int],
) -> torch.Tensor:

    if topk is None:
        return scores

    if topk <= 0:
        return torch.zeros_like(scores)

    if scores.size(1) == 0:
        return scores

    k = min(int(topk), scores.size(1))
    values, indices = torch.topk(scores, k=k, dim=1)
    sparse_scores = torch.zeros_like(scores)

    row_index = ( torch.arange(scores.size(0), device=scores.device).unsqueeze(1).expand(-1, k))
    sparse_scores[row_index, indices] = values

    return sparse_scores

# Construct sparse two-hop virtual edge scores
def fold_two_hop_adj(
    A_src_mid: Optional[torch.Tensor],
    A_mid_dst: Optional[torch.Tensor],
    A_direct: Optional[torch.Tensor] = None,
    mid_degree: Optional[torch.Tensor] = None,
    topk: Optional[int] = 100,
    thresh: float = 1e-3,
    mode: str = "RA",
    max_mid_degree: Optional[float] = None,
    drop_top_mid_ratio: float = 0.0,
    eps: float = 1e-9,
) -> Optional[torch.Tensor]:

    if A_src_mid is None or A_mid_dst is None:
        return None

    A_src_mid = A_src_mid.float()
    A_mid_dst = A_mid_dst.float()

    if mid_degree is None:
        mid_degree = (A_src_mid.sum(dim=0) + A_mid_dst.sum(dim=1))

    mid_degree = mid_degree.to(dtype=torch.float32, device=A_src_mid.device)

    A_src_mid, A_mid_dst, mid_degree = _filter_high_degree_mid_nodes(
        A_src_mid=A_src_mid,
        A_mid_dst=A_mid_dst,
        mid_degree=mid_degree,
        max_mid_degree=max_mid_degree,
        drop_top_mid_ratio=drop_top_mid_ratio,
    )

    if mid_degree.numel() == 0:
        return torch.zeros(
            (A_src_mid.size(0), A_mid_dst.size(1)),
            dtype=torch.float32,
            device=A_src_mid.device,
        )

    mode = mode.upper()

    if mode == "COUNT":
        mid_weights = torch.ones_like(mid_degree)
    elif mode == "AA":
        mid_weights = 1.0 / (torch.log(mid_degree + 1.0) + eps)
    else:
        # Default: Resource Allocation
        mid_weights = 1.0 / (mid_degree + eps)
    scores = (A_src_mid * mid_weights.unsqueeze(0)) @ A_mid_dst

    if A_direct is not None:
        scores = scores * (1.0 - (A_direct > 0).float())
    if thresh > 0:
        scores = torch.where(scores >= thresh, scores, torch.zeros_like(scores))
    scores = _apply_topk_by_row(scores, topk)

    return scores

def _scale_virtual_adj(
        scores: Optional[torch.Tensor],
        A_real: torch.Tensor,
        scale: torch.Tensor,
        eps: float = 1e-9,
) -> torch.Tensor:

    A_real = (A_real > 0).float()

    if scores is None:
        return torch.zeros_like(A_real)

    scores = scores.float() * (1.0 - A_real)
    scores = _row_normalize_scores(scores, eps)

    if scores is None:
        return torch.zeros_like(A_real)

    A_virtual = scores * scale
    A_virtual = A_virtual * (1.0 - A_real)

    return torch.clamp(A_virtual, min=0.0, max=1.0)


def build_twohop_residual_adjs(
        # Real adjacency matrices
        A_lm: torch.Tensor,
        A_ld: torch.Tensor,
        A_md: torch.Tensor,

        # Disease-related adjacencies
        A_l_dis: Optional[torch.Tensor] = None,
        A_dis_m: Optional[torch.Tensor] = None,
        A_dis_d: Optional[torch.Tensor] = None,

        # mRNA-related adjacencies
        A_l_rna: Optional[torch.Tensor] = None,
        A_rna_m: Optional[torch.Tensor] = None,
        A_rna_d: Optional[torch.Tensor] = None,

        # Two-hop configuration
        mid_node_mode: str = "both",

        topk_disease: Optional[int] = 100,
        topk_mrna: Optional[int] = 50,

        thresh_disease: float = 1e-3,
        thresh_mrna: float = 1e-3,

        mode_disease: str = "RA",
        mode_mrna: str = "RA",

        max_mid_degree_disease: Optional[float] = None,
        max_mid_degree_mrna: Optional[float] = None,

        drop_top_mid_ratio_disease: float = 0.0,
        drop_top_mid_ratio_mrna: float = 0.0,

        lambda_disease: torch.Tensor = torch.tensor(0.3),
        lambda_mrna: torch.Tensor = torch.tensor(0.1),
) -> Dict[str, torch.Tensor]:

    mid_node_mode = mid_node_mode.lower()

    if mid_node_mode not in {"none", "disease", "mrna", "both"}:
        raise ValueError(
            "mid_node_mode must be "
            "'none', 'disease', 'mrna', or 'both'."
        )

    # Real adjacency matrices
    A_lm_real = (A_lm > 0).float()
    A_ld_real = (A_ld > 0).float()
    A_md_real = (A_md > 0).float()

    use_disease = mid_node_mode in {"disease", "both"}
    use_mrna = mid_node_mode in {"mrna", "both"}

    # Disease-induced virtual edges
    if use_disease:

        S_lm_dis = fold_two_hop_adj(
            A_l_dis,
            A_dis_m,
            A_direct=A_lm,
            topk=topk_disease,
            thresh=thresh_disease,
            mode=mode_disease,
            max_mid_degree=max_mid_degree_disease,
            drop_top_mid_ratio=drop_top_mid_ratio_disease,
        )

        S_ld_dis = fold_two_hop_adj(
            A_l_dis,
            A_dis_d,
            A_direct=A_ld,
            topk=topk_disease,
            thresh=thresh_disease,
            mode=mode_disease,
            max_mid_degree=max_mid_degree_disease,
            drop_top_mid_ratio=drop_top_mid_ratio_disease,
        )

        S_md_dis = None

        if A_dis_m is not None and A_dis_d is not None:
            S_md_dis = fold_two_hop_adj(
                A_dis_m.t(),
                A_dis_d,
                A_direct=A_md,
                topk=topk_disease,
                thresh=thresh_disease,
                mode=mode_disease,
                max_mid_degree=max_mid_degree_disease,
                drop_top_mid_ratio=drop_top_mid_ratio_disease,
            )

    else:
        S_lm_dis = S_ld_dis = S_md_dis = None

    # mRNA-induced virtual edges
    if use_mrna:

        S_lm_rna = fold_two_hop_adj(
            A_l_rna,
            A_rna_m,
            A_direct=A_lm,
            topk=topk_mrna,
            thresh=thresh_mrna,
            mode=mode_mrna,
            max_mid_degree=max_mid_degree_mrna,
            drop_top_mid_ratio=drop_top_mid_ratio_mrna,
        )

        S_ld_rna = fold_two_hop_adj(
            A_l_rna,
            A_rna_d,
            A_direct=A_ld,
            topk=topk_mrna,
            thresh=thresh_mrna,
            mode=mode_mrna,
            max_mid_degree=max_mid_degree_mrna,
            drop_top_mid_ratio=drop_top_mid_ratio_mrna,
        )

        S_md_rna = None

        if A_rna_m is not None and A_rna_d is not None:
            S_md_rna = fold_two_hop_adj(
                A_rna_m.t(),
                A_rna_d,
                A_direct=A_md,
                topk=topk_mrna,
                thresh=thresh_mrna,
                mode=mode_mrna,
                max_mid_degree=max_mid_degree_mrna,
                drop_top_mid_ratio=drop_top_mid_ratio_mrna,
            )

    else:
        S_lm_rna = S_ld_rna = S_md_rna = None


    # Construct virtual adjacency matrices
    A_lm_dis = _scale_virtual_adj(S_lm_dis, A_lm, lambda_disease)
    A_ld_dis = _scale_virtual_adj(S_ld_dis, A_ld, lambda_disease)
    A_md_dis = _scale_virtual_adj(S_md_dis, A_md, lambda_disease)

    A_lm_rna = _scale_virtual_adj(S_lm_rna, A_lm, lambda_mrna)
    A_ld_rna = _scale_virtual_adj(S_ld_rna, A_ld, lambda_mrna)
    A_md_rna = _scale_virtual_adj(S_md_rna, A_md, lambda_mrna)

    return {
        "A_lm_real": A_lm_real,
        "A_ld_real": A_ld_real,
        "A_md_real": A_md_real,
        "A_lm_dis": A_lm_dis,
        "A_ld_dis": A_ld_dis,
        "A_md_dis": A_md_dis,
        "A_lm_rna": A_lm_rna,
        "A_ld_rna": A_ld_rna,
        "A_md_rna": A_md_rna,
    }

class _FFN(nn.Module):
    def __init__(self, d_model: int, d_ff: int, dropout: float = 0.1):
        super().__init__()
        self.fc1 = nn.Linear(d_model, d_ff)
        self.fc2 = nn.Linear(d_ff, d_model)
        self.drop = nn.Dropout(dropout)

        nn.init.xavier_uniform_(self.fc1.weight, gain=1.414)
        nn.init.zeros_(self.fc1.bias)
        nn.init.xavier_uniform_(self.fc2.weight, gain=1.414)
        nn.init.zeros_(self.fc2.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.fc1(x)
        x = F.gelu(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x

# Relation-aware multi-head attention over three node types
class TriRelAttn(nn.Module):
    def __init__(self, d_model: int, nheads: int = 4, dropout: float = 0.1,
        edge_magnitude_mode: str = "post_softmax"):
        super().__init__()

        if d_model % nheads != 0:
            raise ValueError("d_model must be divisible by nheads.")

        self.d_model = d_model
        self.nheads = nheads
        self.dk = d_model // nheads
        self.edge_magnitude_mode = edge_magnitude_mode

        # LncRNA–miRNA projections
        self.q_lm = nn.Linear(d_model, d_model, bias=False)
        self.k_lm = nn.Linear(d_model, d_model, bias=False)
        self.v_lm = nn.Linear(d_model, d_model, bias=False)

        # LncRNA–drug projections
        self.q_ld = nn.Linear(d_model, d_model, bias=False)
        self.k_ld = nn.Linear(d_model, d_model, bias=False)
        self.v_ld = nn.Linear(d_model, d_model, bias=False)

        # miRNA–drug projections
        self.q_md = nn.Linear(d_model, d_model, bias=False)
        self.k_md = nn.Linear(d_model, d_model, bias=False)
        self.v_md = nn.Linear(d_model, d_model, bias=False)

        # Output projections
        self.out_lm = nn.Linear(d_model, d_model)
        self.out_ld = nn.Linear(d_model, d_model)
        self.out_md = nn.Linear(d_model, d_model)

        self.attn_drop = nn.Dropout(dropout)
        self.feat_drop = nn.Dropout(dropout)

        # Adaptive fusion weights
        self.gate_l = nn.Parameter(torch.zeros(2))
        self.gate_m = nn.Parameter(torch.zeros(2))
        self.gate_d = nn.Parameter(torch.zeros(2))

        self._reset_parameters()

    def _reset_parameters(self):
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.xavier_uniform_(module.weight, gain=1.414)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)

    def _split_heads(self,x: torch.Tensor) -> torch.Tensor:
        num_nodes = x.size(0)
        return ( x.view(num_nodes, self.nheads, self.dk).transpose(0, 1))

    def _combine_heads(self, x: torch.Tensor,) -> torch.Tensor:
        x = x.transpose(0, 1).contiguous()
        return x.view(x.size(0), self.d_model)

    def _masked_attn(
        self,
        Q: torch.Tensor,
        K: torch.Tensor,
        V: torch.Tensor,
        A_weight: torch.Tensor,
        branch: str = "real",
    ) -> torch.Tensor:

        q = self._split_heads(Q)
        k = self._split_heads(K)
        v = self._split_heads(V)
        scores = torch.matmul(q, k.transpose(1, 2)) / math.sqrt(self.dk)

        A_weight = A_weight.float()
        mask = (A_weight > 0).unsqueeze(0)
        scores = scores.masked_fill(~mask, -1e9)

        attn = torch.softmax(scores, dim=-1)
        attn = torch.where(mask, attn, torch.zeros_like(attn))

        # Apply branch-specific normalization
        if branch == "real":
            attn = attn / (attn.sum(dim=-1, keepdim=True) + 1e-9)

        elif branch == "virtual":
            if self.edge_magnitude_mode == "post_softmax":
                attn = attn * A_weight.unsqueeze(0)
        else:
            raise ValueError("branch must be 'real' or 'virtual'.")

        attn = self.attn_drop(attn)
        out = torch.matmul(attn, v)
        out = self._combine_heads(out)
        out = self.feat_drop(out)

        return out

    def _relation_message(
        self,
        Q: torch.Tensor,
        K: torch.Tensor,
        V: torch.Tensor,
        A_real: torch.Tensor,
        A_dis: torch.Tensor,
        A_rna: torch.Tensor,
        out_proj: nn.Linear,
    ) -> torch.Tensor:

        msg_real = self._masked_attn(Q, K, V, A_real, branch="real")
        msg_dis = self._masked_attn(Q, K, V, A_dis,branch="virtual")
        msg_rna = self._masked_attn(Q, K, V, A_rna,branch="virtual")
        msg = msg_real + msg_dis + msg_rna

        return out_proj(msg)

    def forward(
        self,
        x_l: torch.Tensor,
        x_m: torch.Tensor,
        x_d: torch.Tensor,
        A_lm_real: torch.Tensor,
        A_ld_real: torch.Tensor,
        A_md_real: torch.Tensor,
        A_lm_dis: torch.Tensor,
        A_ld_dis: torch.Tensor,
        A_md_dis: torch.Tensor,
        A_lm_rna: torch.Tensor,
        A_ld_rna: torch.Tensor,
        A_md_rna: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:

        # lncRNA <-> miRNA
        l_from_m = self._relation_message( self.q_lm(x_l), self.k_lm(x_m), self.v_lm(x_m),
            A_lm_real, A_lm_dis, A_lm_rna, self.out_lm)

        m_from_l = self._relation_message(self.q_lm(x_m), self.k_lm(x_l), self.v_lm(x_l),
            A_lm_real.t(), A_lm_dis.t(), A_lm_rna.t(), self.out_lm)

        # lncRNA <-> drug
        l_from_d = self._relation_message(self.q_ld(x_l), self.k_ld(x_d), self.v_ld(x_d),
            A_ld_real, A_ld_dis, A_ld_rna, self.out_ld,)

        d_from_l = self._relation_message(self.q_ld(x_d), self.k_ld(x_l), self.v_ld(x_l),
            A_ld_real.t(), A_ld_dis.t(), A_ld_rna.t(), self.out_ld)

        # miRNA <-> drug
        m_from_d = self._relation_message( self.q_md(x_m), self.k_md(x_d), self.v_md(x_d),
            A_md_real, A_md_dis, A_md_rna, self.out_md)

        d_from_m = self._relation_message(self.q_md(x_d), self.k_md(x_m), self.v_md(x_m),
            A_md_real.t(), A_md_dis.t(), A_md_rna.t(), self.out_md)

        # Adaptive fusion of incoming messages
        alpha_l = torch.softmax(self.gate_l, dim=0)
        alpha_m = torch.softmax(self.gate_m, dim=0)
        alpha_d = torch.softmax(self.gate_d, dim=0)

        delta_l = (alpha_l[0] * l_from_m + alpha_l[1] * l_from_d)
        delta_m = (alpha_m[0] * m_from_l + alpha_m[1] * m_from_d)
        delta_d = ( alpha_d[0] * d_from_l + alpha_d[1] * d_from_m)

        return delta_l, delta_m, delta_d

class TransformerBlock(nn.Module):
    def __init__(
        self,
        d_model: int,
        nheads: int = 4,
        dropout: float = 0.1,
        d_ff: Optional[int] = None,
        edge_magnitude_mode: str = "post_softmax",
    ):
        super().__init__()

        if d_ff is None:
            d_ff = 4 * d_model

        # Pre-LayerNorm before attention
        self.ln_l_1 = nn.LayerNorm(d_model)
        self.ln_m_1 = nn.LayerNorm(d_model)
        self.ln_d_1 = nn.LayerNorm(d_model)

        self.attn = TriRelAttn(
            d_model=d_model,
            nheads=nheads,
            dropout=dropout,
            edge_magnitude_mode=edge_magnitude_mode,
        )

        self.res_drop = nn.Dropout(dropout)

        # Pre-LayerNorm before FFN
        self.ln_l_2 = nn.LayerNorm(d_model)
        self.ln_m_2 = nn.LayerNorm(d_model)
        self.ln_d_2 = nn.LayerNorm(d_model)

        self.ffn_l = _FFN(d_model, d_ff, dropout)
        self.ffn_m = _FFN(d_model, d_ff, dropout)
        self.ffn_d = _FFN(d_model, d_ff, dropout)

    def forward(
        self,
        x_l: torch.Tensor,
        x_m: torch.Tensor,
        x_d: torch.Tensor,
        A_lm_real: torch.Tensor,
        A_ld_real: torch.Tensor,
        A_md_real: torch.Tensor,
        A_lm_dis: torch.Tensor,
        A_ld_dis: torch.Tensor,
        A_md_dis: torch.Tensor,
        A_lm_rna: torch.Tensor,
        A_ld_rna: torch.Tensor,
        A_md_rna: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:

        xl = self.ln_l_1(x_l)
        xm = self.ln_m_1(x_m)
        xd = self.ln_d_1(x_d)

        delta_l, delta_m, delta_d = self.attn(xl, xm, xd,
            A_lm_real=A_lm_real,
            A_ld_real=A_ld_real,
            A_md_real=A_md_real,
            A_lm_dis=A_lm_dis,
            A_ld_dis=A_ld_dis,
            A_md_dis=A_md_dis,
            A_lm_rna=A_lm_rna,
            A_ld_rna=A_ld_rna,
            A_md_rna=A_md_rna,
        )

        # Separated residual updates
        x_l = x_l + self.res_drop(delta_l)
        x_m = x_m + self.res_drop(delta_m)
        x_d = x_d + self.res_drop(delta_d)

        xl = self.ln_l_2(x_l)
        xm = self.ln_m_2(x_m)
        xd = self.ln_d_2(x_d)

        x_l = x_l + self.res_drop(self.ffn_l(xl))
        x_m = x_m + self.res_drop(self.ffn_m(xm))
        x_d = x_d + self.res_drop(self.ffn_d(xd))

        return x_l, x_m, x_d

# Sparse Virtual Edge Propagation and Separated Residual Graph Transformer
class SVE_SRGT(nn.Module):
    def __init__(
        self,
        in_l: int,
        in_m: int,
        in_d: int,
        d_model: int,
        nheads: int = 4,
        dropout: float = 0.1,
        num_layers: int = 2,
        d_ff: Optional[int] = None,
        twohop_init_lambda_disease: float = 0.1,
        twohop_init_lambda_mrna: float = 0.1,
        learnable_twohop_lambda: bool = False,
        edge_magnitude_mode: str = "post_softmax",
    ):
        super().__init__()

        self.proj_l = nn.Linear(in_l, d_model)
        self.proj_m = nn.Linear(in_m, d_model)
        self.proj_d = nn.Linear(in_d, d_model)

        for layer in (self.proj_l, self.proj_m, self.proj_d):
            nn.init.xavier_uniform_(layer.weight, gain=1.414)
            nn.init.zeros_(layer.bias)

        # Transformer encoder
        self.blocks = nn.ModuleList(
            [TransformerBlock(
                    d_model=d_model,
                    nheads=nheads,
                    dropout=dropout,
                    d_ff=d_ff,
                    edge_magnitude_mode=edge_magnitude_mode,
                )
                for _ in range(num_layers)
            ]
        )

        # Initial virtual-edge scaling factors
        init_lambda = torch.tensor([float(twohop_init_lambda_disease), float(twohop_init_lambda_mrna),], dtype=torch.float32).clamp(1e-4, 1.0 - 1e-4)
        init_logit = torch.log(init_lambda / (1.0 - init_lambda))

        if learnable_twohop_lambda:
            self.twohop_type_lambda_logit = nn.Parameter(init_logit)
        else:
            self.register_buffer("twohop_type_lambda_logit", init_logit)

    def _get_twohop_type_lambdas(self) -> Tuple[torch.Tensor, torch.Tensor]:

        lambdas = torch.sigmoid(self.twohop_type_lambda_logit)
        return lambdas[0], lambdas[1]

    def forward(
        self,
        H_l: torch.Tensor,
        H_m: torch.Tensor,
        H_d: torch.Tensor,

        # Real adjacency matrices
        A_lm: torch.Tensor,
        A_ld: torch.Tensor,
        A_md: torch.Tensor,

        # Disease-related adjacencies
        A_l_dis: Optional[torch.Tensor] = None,
        A_dis_m: Optional[torch.Tensor] = None,
        A_dis_d: Optional[torch.Tensor] = None,

        # mRNA-related adjacencies
        A_l_rna: Optional[torch.Tensor] = None,
        A_rna_m: Optional[torch.Tensor] = None,
        A_rna_d: Optional[torch.Tensor] = None,

        # Two-hop configuration
        mid_node_mode: str = "both",

        twohop_topk_disease: Optional[int] = None,
        twohop_topk_mrna: Optional[int] = None,

        twohop_thresh_disease: float = 1e-3,
        twohop_thresh_mrna: float = 1e-3,

        twohop_mode_disease: str = "RA",
        twohop_mode_mrna: str = "RA",

        twohop_lambda_disease: Optional[float] = None,
        twohop_lambda_mrna: Optional[float] = None,

        max_mid_degree_disease: Optional[float] = None,
        max_mid_degree_mrna: Optional[float] = None,

        drop_top_mid_ratio_disease: float = 0.0,
        drop_top_mid_ratio_mrna: float = 0.0,

    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:

        x_l = self.proj_l(H_l)
        x_m = self.proj_m(H_m)
        x_d = self.proj_d(H_d)

        # Virtual-edge scaling factors
        lambda_disease, lambda_mrna = (
            self._get_twohop_type_lambdas()
        )

        if twohop_lambda_disease is not None:
            lambda_disease = torch.as_tensor(
                twohop_lambda_disease,
                dtype=x_l.dtype,
                device=x_l.device,
            )

        if twohop_lambda_mrna is not None:
            lambda_mrna = torch.as_tensor(
                twohop_lambda_mrna,
                dtype=x_l.dtype,
                device=x_l.device,
            )

        # Construct separated residual adjacency matrices
        adjs = build_twohop_residual_adjs(
            A_lm=A_lm,
            A_ld=A_ld,
            A_md=A_md,

            A_l_dis=A_l_dis,
            A_dis_m=A_dis_m.t() if A_dis_m is not None else None,
            A_dis_d=A_dis_d.t() if A_dis_d is not None else None,

            A_l_rna=A_l_rna,
            A_rna_m=A_rna_m.t() if A_rna_m is not None else None,
            A_rna_d=A_rna_d.t() if A_rna_d is not None else None,

            mid_node_mode=mid_node_mode,

            topk_disease=twohop_topk_disease,
            topk_mrna=twohop_topk_mrna,

            thresh_disease=twohop_thresh_disease,
            thresh_mrna=twohop_thresh_mrna,

            mode_disease=twohop_mode_disease,
            mode_mrna=twohop_mode_mrna,

            max_mid_degree_disease=max_mid_degree_disease,
            max_mid_degree_mrna=max_mid_degree_mrna,

            drop_top_mid_ratio_disease=drop_top_mid_ratio_disease,
            drop_top_mid_ratio_mrna=drop_top_mid_ratio_mrna,

            lambda_disease=lambda_disease,
            lambda_mrna=lambda_mrna,
        )

        # Stacked Transformer blocks
        for block in self.blocks:

            x_l, x_m, x_d = block(
                x_l,
                x_m,
                x_d,

                A_lm_real=adjs["A_lm_real"],
                A_ld_real=adjs["A_ld_real"],
                A_md_real=adjs["A_md_real"],

                A_lm_dis=adjs["A_lm_dis"],
                A_ld_dis=adjs["A_ld_dis"],
                A_md_dis=adjs["A_md_dis"],

                A_lm_rna=adjs["A_lm_rna"],
                A_ld_rna=adjs["A_ld_rna"],
                A_md_rna=adjs["A_md_rna"],
            )

        x_l = F.relu(x_l)
        x_m = F.relu(x_m)
        x_d = F.relu(x_d)

        return x_l, x_m, x_d
