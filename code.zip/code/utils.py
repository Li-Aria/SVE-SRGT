import numpy as np
import torch
from sklearn.preprocessing import scale
from sklearn.preprocessing import StandardScaler


def multiomics_data():

    # RNAi_fea
    fea1 = np.genfromtxt("lncrna attribute file1 path", delimiter=' ', dtype=np.dtype(str)) # our_kmer and g_gap (sequence & structure)
    fea2 = np.genfromtxt("lncrna attribute file2 path", delimiter=' ', dtype=np.dtype(str)) # Word2Vec_TF
    fea3 = np.genfromtxt("lncrna attribute file3 path", delimiter=' ', dtype=np.dtype(str)) # Pseudo protein related
    fea4 = np.genfromtxt("lncrna attribute file4 path", delimiter=' ', dtype=np.dtype(str)) # Global transcript sequence descriptors
    fea5 = np.genfromtxt("lncrna attribute file5 path", delimiter=' ', dtype=np.dtype(str)) # GC content properties
    fea6 = np.genfromtxt("lncrna attribute file6 path", delimiter=' ', dtype=np.dtype(str)) # Autocorrelation of dinucleotide & Pseudo dinucleotide composition
    rna_i = np.hstack((fea1, fea2, fea3, fea4, fea5, fea6))
    protein = rna_i[:, 0]
    rna_i = np.array(rna_i)
    rna_i = scale(np.array(rna_i[:, 0:], dtype=float))
    rna_i = np.round(rna_i, decimals=4)

    # RNAj_fea
    # RNAj_fea
    fea1 = np.genfromtxt("mirna attribute file1 path", delimiter=' ', dtype=np.dtype(str))
    fea2 = np.genfromtxt("mirna attribute file2 path", delimiter=' ', dtype=np.dtype(str))
    fea3 = np.genfromtxt("mirna attribute file3 path", delimiter=' ', dtype=np.dtype(str))
    fea4 = np.genfromtxt("mirna attribute file4 path", delimiter=' ', dtype=np.dtype(str))
    fea5 = np.genfromtxt("mirna attribute file5 path", delimiter=' ', dtype=np.dtype(str))
    fea6 = np.genfromtxt("mirna attribute file6 path", delimiter=' ', dtype=np.dtype(str))
    rna_j = np.hstack((fea1, fea2, fea3, fea4, fea5, fea6))
    drug = rna_j[:, 0]
    rna_j = np.array(rna_j)
    rna_j = scale(np.array(rna_j[:, 0:], dtype=float))
    rna_j = np.round(rna_j, decimals=4)

    # Drug_fea
    fea1 = np.genfromtxt("mirna attribute file1 path", delimiter=',', dtype=float, skip_header=1, filling_values=0.0)  # fea_ECFP
    fea2 = np.genfromtxt("mirna attribute file2 path", delimiter=',', dtype=float, skip_header=1, filling_values=0.0)  # fea_FCFP
    fea3 = np.genfromtxt("mirna attribute file3 path", delimiter=',', dtype=float, skip_header=1, filling_values=0.0)  # fea_MACCS
    fea4 = np.genfromtxt("mirna attribute file4 path", delimiter=',', dtype=float, skip_header=1, filling_values=0.0)  # fea_phy_chem
    fea5 = np.genfromtxt("mirna attribute file5 path", delimiter=',', dtype=float, skip_header=1, filling_values=0.0)  # fea_PubChem
    drug = np.hstack((fea1[:, 1:], fea2[:, 1:], fea3[:, 1:], fea4[:, 1:], fea5[:, 1:]))
    scaler = StandardScaler()
    drug = scaler.fit_transform(drug)
    drug = np.round(drug, 4)
    drug_fea = np.round(drug, decimals=4)

    ldalist = torch.from_numpy(np.loadtxt('LDA_label train file path', dtype=int)).float()
    lda_test = torch.from_numpy(np.loadtxt('LDA_label tEST file path', dtype=int)).float()

    mdalist = torch.from_numpy(np.loadtxt('MDA_label train file path', dtype=int)).float()
    mda_test = torch.from_numpy(np.loadtxt('MDA_label test file path', dtype=int)).float()

    lmilist = torch.from_numpy(np.loadtxt('LMI_label train file path', dtype=int)).float()
    lmi_test = torch.from_numpy(np.loadtxt('LMI_label test file path', dtype=int)).float()

    # real association matrix
    lda_adj = load_adj("LDA_label train file path",num_lnc=641, num_mir=171)
    mda_adj = load_adj("MDA_label train file path", num_lnc=295, num_mir=171)
    lmi_adj = load_adj("LMI_label test file path", num_lnc=641, num_mir=295)

    # Disease- and mRNA-related adjacency matrices
    ldis_adj = load_adj("lnc_dis label file path", num_lnc=641, num_mir=397)
    mdis_adj = load_adj("mi_dis label file path",num_lnc=295, num_mir=397)
    ddis_adj = load_adj("drug_dis label file path", num_lnc=171, num_mir=397)

    lm_adj = load_adj("lnc_mrna label file path", num_lnc=641, num_mir=3693)
    mm_adj = load_adj("mi_mrna label file path",num_lnc=295, num_mir=3693)
    dm_adj = load_adj("drug_mrna label file path", num_lnc=171, num_mir=3693)

    rnai_fea, rnaj_fea = torch.FloatTensor(rna_i),  torch.FloatTensor(rna_j)
    drug_fea, lda_adj, mda_adj = torch.FloatTensor(drug_fea), torch.FloatTensor(lda_adj), torch.FloatTensor(mda_adj)

    return rnai_fea ,rnaj_fea, drug_fea, lda_adj, mda_adj, ldalist, lda_test, mdalist, mda_test, lmilist, lmi_test, lmi_adj, \
          ldis_adj, mdis_adj, ddis_adj, lm_adj, mm_adj, dm_adj


def load_adj(label_file, num_lnc, num_mir):
    lmi_adj = np.zeros((num_lnc, num_mir), dtype=np.float32)
    with open(label_file, "r") as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) != 3:
                continue
            l_idx = int(parts[0])
            m_idx = int(parts[1])
            label = int(parts[2])
            lmi_adj[l_idx][m_idx] = label

    return lmi_adj


