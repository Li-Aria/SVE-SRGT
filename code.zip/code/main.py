import argparse
import copy
import random
import time
from datetime import datetime

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.utils.data as Dataset
from scipy.stats import pearsonr
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    f1_score,
    mean_absolute_error,
    mean_squared_error,
    precision_score,
    r2_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import StratifiedKFold

from model import MultiDeep
from utils import multiomics_data


parser = argparse.ArgumentParser()
parser.add_argument("--seed", type=int, default=42, help="Random seed")
parser.add_argument("--epochs", type=int, default=100, help="Number of epochs to train")
parser.add_argument("--lr", type=float, default=5e-4, help="Initial learning rate")
parser.add_argument("--batch", type=int, default=128, help="Number of batch size")
parser.add_argument("--patience", type=int, default=8, help="Patience")
parser.add_argument(
    "--task",
    choices=("mda", "lda"),
    default="mda",
    help="mda denotes miRNA-drug; lda denotes lncRNA-drug",
)
args = parser.parse_args()


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


set_seed(args.seed)
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


# multiomics_data should ensure that the independent test set is excluded from the development set.
(
    rnai_fea,
    rnaj_fea,
    drug_fea,
    lda_adj,
    mda_adj,
    ldalist,
    lda_test,
    mdalist,
    mda_test,
    lmilist,
    lmi_test,
    lmi_adj,
    ldis_adj,
    mdis_adj,
    ddis_adj,
    lm_adj,
    mm_adj,
    dm_adj,
) = multiomics_data()


def as_tensor(data, dtype=None):
    tensor = data if torch.is_tensor(data) else torch.as_tensor(data)
    return tensor.to(dtype=dtype) if dtype is not None else tensor


rnai_fea = as_tensor(rnai_fea).to(device)
rnaj_fea = as_tensor(rnaj_fea).to(device)
drug_fea = as_tensor(drug_fea).to(device)

ldalist = as_tensor(ldalist).cpu()
mdalist = as_tensor(mdalist).cpu()
lda_test = as_tensor(lda_test).cpu()
mda_test = as_tensor(mda_test).cpu()

graph_adjs = {
    "lmi": as_tensor(lmi_adj).to(device),
    "lda": as_tensor(lda_adj).to(device),
    "mda": as_tensor(mda_adj).to(device),
    "ldis": as_tensor(ldis_adj).to(device),
    "mdis": as_tensor(mdis_adj).to(device),
    "ddis": as_tensor(ddis_adj).to(device),
    "lm": as_tensor(lm_adj).to(device),
    "mm": as_tensor(mm_adj).to(device),
    "dm": as_tensor(dm_adj).to(device),
}

if args.task == "mda":
    train_set, test_set = mdalist, mda_test
else:
    train_set, test_set = ldalist, lda_test

X = train_set[:, :2].long().cpu()
y = train_set[:, 2].float().cpu()
index_test = test_set[:, :2].long().cpu()
y_test = test_set[:, 2].float().cpu()


def mask_positive_target_edges(adj, pairs, labels):
    """Remove positive edges in the given samples from the target association matrix."""
    masked_adj = adj.clone()
    positive_pairs = pairs[labels > 0.5].long().cpu()
    if positive_pairs.numel() == 0:
        return masked_adj

    rows = positive_pairs[:, 0]
    cols = positive_pairs[:, 1]
    if rows.min() < 0 or cols.min() < 0:
        raise IndexError("Sample indices must be non-negative")
    if rows.max() >= masked_adj.shape[0] or cols.max() >= masked_adj.shape[1]:
        raise IndexError(
            f"Sample indices do not match the dimensions of the {args.task} adjacency matrix: "
            f"maximum index=({rows.max().item()}, {cols.max().item()}), "
            f"adjacency matrix shape={tuple(masked_adj.shape)}. "
            "Verify that the two sample columns contain the ncRNA and drug indices, respectively."
        )

    rows = rows.to(masked_adj.device)
    cols = cols.to(masked_adj.device)
    masked_adj[rows, cols] = 0
    return masked_adj


# Explicitly remove independent-test positive edges even if utils returns the full network.
# Each fold starts from this development graph, so test edges never enter training or validation.
base_graph_adjs = {name: adj.clone() for name, adj in graph_adjs.items()}
base_graph_adjs[args.task] = mask_positive_target_edges(
    base_graph_adjs[args.task], index_test, y_test
)


def build_model():
    """Create a fresh model and optimizer for each fold."""
    new_model = MultiDeep(
        nlncfeat=rnai_fea.shape[1],
        nmifeat=rnaj_fea.shape[1],
        ndrugfeat=drug_fea.shape[1],
        dim_hidden=128,
        task=args.task,
    ).to(device)
    new_optimizer = optim.Adam(new_model.parameters(), lr=args.lr)
    return new_model, new_optimizer


loss_func = nn.BCEWithLogitsLoss().to(device)


def model_forward(model, pair_indices, adjs):
    """Use a shared forward wrapper to prevent training indices from leaking into validation."""
    return model(
        rnai_fea,
        rnaj_fea,
        drug_fea,
        pair_indices.cpu().numpy().astype(int),
        device,
        adjs["lmi"],
        adjs["lda"],
        adjs["mda"],
        adjs["ldis"],
        adjs["mdis"],
        adjs["ddis"],
        adjs["lm"],
        adjs["mm"],
        adjs["dm"],
    )


def train_one_epoch(model, optimizer, index_train, y_train, adjs):
    model.train()
    dataset = Dataset.TensorDataset(index_train, y_train)
    loader = Dataset.DataLoader(dataset, batch_size=args.batch, shuffle=True)
    for pair_indices, labels in loader:
        labels = labels.to(device)
        optimizer.zero_grad()
        logits = model_forward(model, pair_indices, adjs)
        loss = loss_func(logits, labels)
        loss.backward()
        optimizer.step()


def predict(model, indices, labels, adjs):
    model.eval()
    loader = Dataset.DataLoader(
        Dataset.TensorDataset(indices, labels),
        batch_size=args.batch,
        shuffle=False,
    )
    predictions, truths = [], []
    with torch.no_grad():
        for pair_indices, batch_labels in loader:
            logits = model_forward(model, pair_indices, adjs)
            predictions.extend(torch.sigmoid(logits).cpu().numpy().reshape(-1))
            truths.extend(batch_labels.cpu().numpy().reshape(-1))
    return np.asarray(truths), np.asarray(predictions)


def classification_metrics(truths, predictions):
    binary_predictions = (predictions >= 0.5).astype(int)
    return {
        "AUC": roc_auc_score(truths, predictions),
        "AUPR": average_precision_score(truths, predictions),
        "ACC": accuracy_score(truths, binary_predictions),
        "Precision": precision_score(truths, binary_predictions, zero_division=0),
        "Recall": recall_score(truths, binary_predictions, zero_division=0),
        "F1": f1_score(truths, binary_predictions, zero_division=0),
    }


start_time = time.time()
skf = StratifiedKFold(n_splits=10, shuffle=True, random_state=2024)
fold_results = []
best_epochs = []

for fold, (train_ids, valid_ids) in enumerate(skf.split(X, y), start=1):
    print(f"Starting fold {fold}")
    index_train, y_train = X[train_ids], y[train_ids]
    index_valid, y_valid = X[valid_ids], y[valid_ids]

    # Mask only positive validation associations; negative samples are not graph edges.
    fold_adjs = {name: adj.clone() for name, adj in base_graph_adjs.items()}
    fold_adjs[args.task] = mask_positive_target_edges(
        fold_adjs[args.task], index_valid, y_valid
    )

    # Initialize every fold independently without reusing parameters or optimizer state.
    set_seed(args.seed + fold)
    model, optimizer = build_model()
    fold_best_state = None
    fold_best_metrics = None
    fold_best_epoch = 0
    best_score = (-np.inf, -np.inf)
    bad_counter = 0

    for epoch in range(1, args.epochs + 1):
        train_one_epoch(model, optimizer, index_train, y_train, fold_adjs)
        valid_true, valid_pred = predict(
            model, index_valid, y_valid, fold_adjs
        )
        valid_metrics = classification_metrics(valid_true, valid_pred)

        # Select checkpoints by AUPR first and AUC second.
        current_score = (valid_metrics["AUPR"], valid_metrics["AUC"])
        if current_score > best_score:
            best_score = current_score
            fold_best_metrics = valid_metrics
            fold_best_epoch = epoch
            fold_best_state = copy.deepcopy(model.state_dict())
            bad_counter = 0
        else:
            bad_counter += 1
            if bad_counter >= args.patience:
                break

    model.load_state_dict(fold_best_state)
    fold_results.append(fold_best_metrics)
    best_epochs.append(fold_best_epoch)
    print(
        f"Fold {fold}: epoch={fold_best_epoch}, "
        f"AUC={fold_best_metrics['AUC']:.4f}, "
        f"AUPR={fold_best_metrics['AUPR']:.4f}, "
        f"ACC={fold_best_metrics['ACC']:.4f}"
    )


for metric_name in ("AUC", "AUPR", "ACC", "Precision", "Recall", "F1"):
    values = np.asarray(
        [result[metric_name] for result in fold_results],
        dtype=float,
    )
    print(f"CV {metric_name}: " f"{values.mean():.4f} ± {values.std(ddof=1):.4f}")


# Use 10-fold CV for model selection, then retrain the final model on the full development set.
final_epochs = max(1, int(np.median(best_epochs)))
set_seed(args.seed)
model, optimizer = build_model()
for _ in range(final_epochs):
    train_one_epoch(model, optimizer, X, y, base_graph_adjs)

# Evaluate the independent test set once; all positive test edges are absent from base_graph_adjs.
test_true, test_pred = predict(model, index_test, y_test, base_graph_adjs)
test_metrics = classification_metrics(test_true, test_pred)
mse = mean_squared_error(test_true, test_pred)
test_metrics.update(
    {
        "RMSE": np.sqrt(mse),
        "MAE": mean_absolute_error(test_true, test_pred),
        "PCC": pearsonr(test_true, test_pred)[0],
        "R2": r2_score(test_true, test_pred),
    }
)

model_date = datetime.now().strftime("%Y-%m-%d %H-%M-%S")
with open("MultiMDI", "a", encoding="utf-8") as output_file:
    output_file.write(
        f"{model_date} task={args.task} final_epochs={final_epochs} "
        + " ".join(f"{key}={value}" for key, value in test_metrics.items())
        + "\n"
    )

print(f"Final training epochs: {final_epochs}")
print("Independent test results:")
for metric_name, value in test_metrics.items():
    print(f"{metric_name}: {value:.4f}")
print(f"Total runtime: {time.time() - start_time:.4f}s")
